import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["LOOPBITE_DATA"] = tempfile.mkdtemp()
import storage, rewards, impact, forecast


def cust():
    return {"name": "T", "tokens": 0, "credits": 0, "on_time_returns": 0}


def order(day="2026-11-01", n=3):
    return {"order_id": "O1", "customer_id": "C001", "date": day, "containers": n, "returned": 0, "status": "open"}


class Tests(unittest.TestCase):
    def test_storage_roundtrip_and_corrupt(self):
        storage.save("t", {"a": 1})
        self.assertEqual(storage.load("t", {}), {"a": 1})
        open(os.path.join(storage.data_dir(), "t.json"), "w").write("{bad")
        self.assertEqual(storage.load("t", {"x": 0}), {"x": 0})

    def test_quota(self):
        self.assertFalse(rewards.validate_quota([], "C001", 5)[0])
        os_ = [order(n=4)]
        self.assertFalse(rewards.validate_quota(os_, "C001", 3)[0])
        self.assertTrue(rewards.validate_quota(os_, "C001", 2)[0])

    def test_on_time_return_rewards_and_token(self):
        c, o = cust(), order()
        r = rewards.process_return(c, o, 3, "2026-11-05")
        self.assertEqual((r["refund"], r["credits"], r["tokens"]), (60, 30, 1))
        self.assertEqual(o["status"], "closed")

    def test_late_return_forfeits(self):
        c, o = cust(), order()
        r = rewards.process_return(c, o, 2, "2026-11-20")
        self.assertEqual((r["refund"], r["forfeited"], c["credits"]), (0, 40, 0))

    def test_over_return_rejected(self):
        with self.assertRaises(ValueError):
            rewards.process_return(cust(), order(n=1), 2, "2026-11-02")

    def test_logger_and_forecast(self):
        impact.log_event("2026-11-02", "returned_on_time", 4)
        self.assertEqual(impact.day_report("2026-11-02")["plastic_avoided_g"], 100)
        os_ = [order(day="2026-11-02", n=7)]
        f = forecast.forecast(os_, "2026-11-02")
        self.assertEqual(f["avg_daily_demand"], 1.0)
        self.assertEqual(f["recommended_pool_size"], 11)  # ceil(1*9*1.2)


if __name__ == "__main__":
    unittest.main()
