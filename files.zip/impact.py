"""Daily logger & environmental-impact engine (owner: Vaibhav Dwivedi)."""
import storage

PLASTIC_G_PER_CONTAINER = 25   # ASSUMPTION: replace with a cited value in the final report


def log_event(day, kind, n):
    log = storage.load("daily_log", {})
    d = log.setdefault(day, {"issued": 0, "returned_on_time": 0, "returned_late": 0})
    d[kind] += n
    storage.save("daily_log", log)


def day_report(day):
    d = storage.load("daily_log", {}).get(day)
    if not d:
        return None
    return {**d, "plastic_avoided_g": d["returned_on_time"] * PLASTIC_G_PER_CONTAINER}


def totals():
    log = storage.load("daily_log", {})
    issued = sum(d["issued"] for d in log.values())
    on_time = sum(d["returned_on_time"] for d in log.values())
    late = sum(d["returned_late"] for d in log.values())
    return {"issued": issued, "returned_on_time": on_time, "returned_late": late,
            "plastic_avoided_g": on_time * PLASTIC_G_PER_CONTAINER}
