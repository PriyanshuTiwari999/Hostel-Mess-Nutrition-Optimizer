"""Container-demand forecasting & analytics (owner: Prithvi Singh)."""
import math
from datetime import date, timedelta
import rewards

WASH_TURNAROUND_DAYS = 2   # ASSUMPTION: collection -> hub wash -> restock
SAFETY_FACTOR = 1.2


def daily_demand(orders, end_day, window=7):
    end = date.fromisoformat(end_day)
    days = [(end - timedelta(days=i)).isoformat() for i in range(window - 1, -1, -1)]
    return {d: sum(o["containers"] for o in orders if o["date"] == d) for d in days}


def forecast(orders, end_day, window=7):
    series = daily_demand(orders, end_day, window)
    avg = sum(series.values()) / window
    pool = math.ceil(avg * (rewards.RETURN_WINDOW_DAYS + WASH_TURNAROUND_DAYS) * SAFETY_FACTOR)
    return {"avg_daily_demand": round(avg, 2), "next_7_days": round(avg * 7),
            "recommended_pool_size": pool, "series": series}


def analytics(orders):
    total = len(orders)
    issued = sum(o["containers"] for o in orders)
    returned = sum(o["returned"] for o in orders)
    return {"orders": total, "containers_issued": issued, "containers_returned": returned,
            "return_rate_pct": round(100 * returned / issued, 1) if issued else 0.0,
            "still_out": issued - returned}
