"""LoopBite CLI - navigation & input validation (owner: Shivalik Sharma).
Run:  python main.py        (set LOOPBITE_TODAY=YYYY-MM-DD to override today's date)"""
import os
import random
from datetime import date, timedelta
import storage, rewards, impact, forecast


def today():
    return os.environ.get("LOOPBITE_TODAY", date.today().isoformat())


# ---------- input validation helpers ----------
def ask_int(prompt, lo, hi):
    while True:
        raw = input(prompt).strip()
        if raw.lstrip("-").isdigit() and lo <= int(raw) <= hi:
            return int(raw)
        print(f"  Enter a whole number between {lo} and {hi}.")


def ask_text(prompt, max_len=40):
    while True:
        raw = input(prompt).strip()
        if raw and len(raw) <= max_len:
            return raw
        print(f"  Text required (max {max_len} characters).")


def ask_yes_no(prompt):
    while True:
        raw = input(prompt + " [y/n]: ").strip().lower()
        if raw in ("y", "n"):
            return raw == "y"
        print("  Please type y or n.")


# ---------- data access ----------
def customers():
    return storage.load("customers", {})


def orders():
    return storage.load("orders", [])


def pick_customer():
    cs = customers()
    if not cs:
        print("  No customers yet. Register one first.")
        return None, cs
    for cid, c in cs.items():
        print(f"  {cid}: {c['name']}")
    cid = ask_text("Customer ID: ").upper()
    if cid not in cs:
        print("  Unknown customer ID.")
        return None, cs
    return cid, cs


# ---------- menu actions ----------
def register():
    cs = customers()
    cid = f"C{len(cs) + 1:03d}"
    cs[cid] = {"name": ask_text("Name: "), "tokens": 0, "credits": 0, "on_time_returns": 0}
    storage.save("customers", cs)
    print(f"  Registered {cid}.")


def place_order():
    cid, cs = pick_customer()
    if not cid:
        return
    os_ = orders()
    restaurant = ask_text("Restaurant: ")
    n = 0
    if ask_yes_no("Use returnable containers (deposit Rs %d each)?" % rewards.DEPOSIT):
        n = ask_int(f"How many containers (1-{rewards.MAX_PER_ORDER}): ", 1, 99)
        ok, msg = rewards.validate_quota(os_, cid, n)
        if not ok:
            print("  " + msg)
            return
    fee = rewards.DELIVERY_FEE
    if cs[cid]["tokens"] > 0 and ask_yes_no(f"Use a free-delivery token ({cs[cid]['tokens']} available)?"):
        rewards.redeem_token(cs[cid])
        fee = 0
    order = {"order_id": f"O{len(os_) + 1:04d}", "customer_id": cid, "date": today(),
             "restaurant": restaurant, "containers": n, "returned": 0,
             "deposit": n * rewards.DEPOSIT, "fee": fee,
             "status": "open" if n else "closed"}
    os_.append(order)
    storage.save("orders", os_)
    storage.save("customers", cs)
    if n:
        impact.log_event(today(), "issued", n)
    print(f"  Order {order['order_id']} placed. Deposit Rs {order['deposit']}, delivery Rs {fee}.")


def return_containers():
    cid, cs = pick_customer()
    if not cid:
        return
    os_ = orders()
    open_orders = [o for o in os_ if o["customer_id"] == cid and o["containers"] > o["returned"]]
    if not open_orders:
        print("  No containers outstanding.")
        return
    for o in open_orders:
        print(f"  {o['order_id']} ({o['date']}): {o['containers'] - o['returned']} outstanding")
    oid = ask_text("Order ID: ").upper()
    order = next((o for o in open_orders if o["order_id"] == oid), None)
    if not order:
        print("  Not an open order for this customer.")
        return
    count = ask_int("Containers handed back: ", 1, order["containers"] - order["returned"])
    res = rewards.process_return(cs[cid], order, count, today())
    storage.save("orders", os_)
    storage.save("customers", cs)
    impact.log_event(today(), "returned_on_time" if res["on_time"] else "returned_late", count)
    if res["on_time"]:
        print(f"  Refund Rs {res['refund']}, +{res['credits']} credits, +{res['tokens']} token(s).")
    else:
        print(f"  Late return: deposit Rs {res['forfeited']} forfeited, no rewards.")


def wallet():
    cid, cs = pick_customer()
    if cid:
        c = cs[cid]
        print(f"  {c['name']}: {c['tokens']} tokens, {c['credits']} credits, "
              f"{rewards.outstanding(orders(), cid)} containers held.")


def impact_report():
    r = impact.day_report(today())
    print("  Today:", r if r else "no activity logged")
    print("  All time:", impact.totals())


def forecast_report():
    os_ = orders()
    f = forecast.forecast(os_, today())
    print(f"  Avg daily container demand (7d): {f['avg_daily_demand']}")
    print(f"  Expected next 7 days: {f['next_7_days']}; recommended pool size: {f['recommended_pool_size']}")
    print("  Analytics:", forecast.analytics(os_))


def seed_demo():
    """SIMULATED data for demo only - never present as real results."""
    rng = random.Random(42)
    cs = {f"C{i:03d}": {"name": n, "tokens": 0, "credits": 0, "on_time_returns": 0}
          for i, n in enumerate(["Asha", "Ravi", "Meera", "Kabir", "Sana"], 1)}
    os_, base = [], date.fromisoformat(today())
    for d in range(14, 0, -1):
        day = (base - timedelta(days=d)).isoformat()
        for _ in range(rng.randint(2, 5)):
            cid = rng.choice(list(cs))
            n = rng.randint(1, 3)
            if not rewards.validate_quota(os_, cid, n)[0]:
                continue
            o = {"order_id": f"O{len(os_) + 1:04d}", "customer_id": cid, "date": day,
                 "restaurant": "Demo Kitchen", "containers": n, "returned": 0,
                 "deposit": n * rewards.DEPOSIT, "fee": rewards.DELIVERY_FEE, "status": "open"}
            os_.append(o)
            impact.log_event(day, "issued", n)
            if rng.random() < 0.7:  # simulated 70% return behaviour
                rday = (date.fromisoformat(day) + timedelta(days=rng.randint(1, 9))).isoformat()
                if rday <= today():
                    res = rewards.process_return(cs[cid], o, n, rday)
                    impact.log_event(rday, "returned_on_time" if res["on_time"] else "returned_late", n)
    storage.save("customers", cs)
    storage.save("orders", os_)
    print(f"  Seeded {len(cs)} simulated customers and {len(os_)} simulated orders.")


MENU = [("Register customer", register), ("Place order", place_order),
        ("Return containers", return_containers), ("Customer wallet", wallet),
        ("Daily impact report", impact_report), ("Demand forecast & analytics", forecast_report),
        ("Load SIMULATED demo data", seed_demo)]


def main():
    print("=== LoopBite: Packaging Exchange (prototype) ===")
    while True:
        print("\nMenu")
        for i, (label, _) in enumerate(MENU, 1):
            print(f"  {i}. {label}")
        print("  0. Exit")
        choice = ask_int("Choose: ", 0, len(MENU))
        if choice == 0:
            print("Goodbye.")
            return
        MENU[choice - 1][1]()


if __name__ == "__main__":
    main()
