"""Rebate rule engine & quota validation (owner: Priyanshu Tiwari).
All numbers are design ASSUMPTIONS for the prototype, not measured values."""
from datetime import date

DEPOSIT = 20                 # Rs per container, refunded on return
DELIVERY_FEE = 30            # Rs standard delivery fee
MAX_PER_ORDER = 4            # containers a customer may opt into per order
MAX_OUTSTANDING = 6          # containers a customer may hold un-returned
RETURN_WINDOW_DAYS = 7       # return after this => deposit forfeited
CREDITS_PER_CONTAINER = 10   # partner-store loyalty credits per on-time return
CONTAINERS_PER_TOKEN = 3     # every 3 on-time returns => 1 free-delivery token


def outstanding(orders, customer_id):
    return sum(o["containers"] - o["returned"]
               for o in orders if o["customer_id"] == customer_id)


def validate_quota(orders, customer_id, requested):
    if requested < 1:
        return False, "Request at least 1 container."
    if requested > MAX_PER_ORDER:
        return False, f"Max {MAX_PER_ORDER} containers per order."
    held = outstanding(orders, customer_id)
    if held + requested > MAX_OUTSTANDING:
        return False, (f"Quota exceeded: you hold {held} un-returned containers "
                       f"(limit {MAX_OUTSTANDING}). Return some first.")
    return True, "OK"


def is_on_time(order_date, today):
    return (date.fromisoformat(today) - date.fromisoformat(order_date)).days <= RETURN_WINDOW_DAYS


def process_return(customer, order, count, today):
    """Mutates customer/order; returns a result dict. Caller persists."""
    left = order["containers"] - order["returned"]
    if count < 1 or count > left:
        raise ValueError(f"Can return between 1 and {left} containers for this order.")
    on_time = is_on_time(order["date"], today)
    old_total = customer["on_time_returns"]
    result = {"refund": 0, "credits": 0, "tokens": 0, "forfeited": 0, "on_time": on_time}
    if on_time:
        customer["on_time_returns"] += count
        result["refund"] = count * DEPOSIT
        result["credits"] = count * CREDITS_PER_CONTAINER
        result["tokens"] = customer["on_time_returns"] // CONTAINERS_PER_TOKEN - old_total // CONTAINERS_PER_TOKEN
        customer["credits"] += result["credits"]
        customer["tokens"] += result["tokens"]
    else:
        result["forfeited"] = count * DEPOSIT   # container still accepted, no reward
    order["returned"] += count
    order["status"] = "closed" if order["returned"] == order["containers"] else "open"
    return result


def redeem_token(customer):
    if customer["tokens"] < 1:
        return False
    customer["tokens"] -= 1
    return True
