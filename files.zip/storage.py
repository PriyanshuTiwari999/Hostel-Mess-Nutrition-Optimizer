"""File I/O & data persistence (owner: Abhinav Bhandari).
Atomic JSON read/write so a crash never leaves a half-written file."""
import json
import os
import tempfile


def data_dir():
    return os.environ.get("LOOPBITE_DATA",
                          os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"))


def _path(name):
    return os.path.join(data_dir(), f"{name}.json")


def load(name, default):
    os.makedirs(data_dir(), exist_ok=True)
    p = _path(name)
    if not os.path.exists(p):
        return default
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        os.replace(p, p + ".corrupt")  # keep the bad file for inspection
        return default


def save(name, data):
    os.makedirs(data_dir(), exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=data_dir(), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, _path(name))  # atomic swap
